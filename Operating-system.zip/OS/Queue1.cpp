/*
 * Queue1.cpp
 *
 *  Created on: Aug 10, 2017
 *      Author: OS1
 */




#include "Queue1.h"
#include "pcb.h"


Queue1::Queue1() {
	prvi=posl=0;
}

Queue1::~Queue1() {

	Elem * stari;
	Elem * tmp;
	tmp=prvi;

	while (tmp != 0 ) {
		stari=tmp;
		tmp=tmp->sled;
		delete stari;
	}

	prvi=posl=0;
}


void Queue1::insert(PCB * ni, int x) {
	Elem * novi= new Elem (ni,x);
	if (posl == 0) {
		posl=prvi=novi;
	}
	else {
		posl->sled=novi;
	}

	posl=novi;
}


Queue1::Elem * Queue1::take() {

	if (prvi == 0 ) return 0;

	Elem * tmp = prvi;

	prvi=prvi->sled;
	if (prvi == 0 ) posl=0;

	return tmp;
}


PCB * Queue1::take (PCB * pcb ) {

	Elem * tek, * ret, *pret;
		tek=prvi; pret=0;
		if (prvi == 0) return 0;
		while (tek->pcb != pcb) {
			pret=tek;
			tek=tek->sled;

		}
		ret=tek;

		if (tek == prvi) {
			prvi=prvi->sled;
			if (prvi == 0) posl=prvi;
		}
		else {
			if (tek->sled == 0) posl=pret;
			pret->sled=tek->sled;

		}

		return pcb;

}

