/*
 * pcb.cpp
 *
 *  Created on: Aug 9, 2017
 *      Author: OS1
 */




#include "pcb.h"
#include <dos.h>
#include "globalna.h"
#include "SCHEDULE.h"
#include "queue.h"
#include <assert.h>
#include <iostream.h>
#include <stdlib.h>

unsigned PCB::maxStackSize=65536 - 1;
void* operator new(unsigned size)
{
#ifndef BCC_BLOCK_IGNORE
	asm { pushf; cli; }
#endif
	void* p = malloc(size);
#ifndef BCC_BLOCK_IGNORE
	asm { popf; }
#endif
	return p;
}

void operator delete(void* p)
{
#ifndef BCC_BLOCK_IGNORE
	asm { pushf; cli; }
#endif
	free(p);
#ifndef BCC_BLOCK_IGNORE
	asm { popf; }
#endif
}
void PCB::start() {

	if (flagStarted == 1) return;
	flagStarted=1;

	stack[size - 1 ] = 0x200;
#ifndef BCC_BLOCK_IGNORE
	stack[size - 2 ] = FP_SEG(&(PCB::wrapper));
	stack[size - 3]= FP_OFF(&(PCB::wrapper));
#endif

#ifndef BCC_BLOCK_IGNORE
	sp=FP_OFF(stack + size - 12);
#endif
	bp=sp;
#ifndef BCC_BLOCK_IGNORE
	ss=FP_SEG(stack + size - 12);
#endif

	if (flagAmIidle == 0)
Scheduler::put(this);

state=threadReady;


}


void PCB::waitToComplete() {

	if (Globalna::running == this ) return;

	if (this->state == threadFinished) return;

	//if (this->state == threadNew) return;

	Globalna::running->state=threadBlocked;
	blockedThreads->insert(Globalna::running);

	//if (flagAmIidle == 1 )
		//if (Globalna::running== Globalna::firstThread->myPCB) {
		//	PCB * tmp = Scheduler::get();
		//	if (tmp != 0) assert (0);
		//}


	dispatch();




}


PCB::PCB(StackSize size, Time timeslice, Thread * nit) {

	flagAmIidle=0;
	flagStarted=0;

	blockedThreads=new Queue();

	this->timeSlice=timeslice;

	this->nit=nit;
	if (size>maxStackSize) {
		size=maxStackSize;

	}
	this->size=size/2; //*************************************************************

	//this->timeSlice=timeslice;

	ss=sp=bp=0;
	stack=new unsigned [size];

	state=threadNew;
	flagWokeUp=0;
}


PCB::~PCB() {

	delete [] stack;
	delete blockedThreads;


}


void PCB::wrapper() {

	Globalna::running->nit->run();

	//if (Globalna::running->flagAmIidle == 1 ) assert (0);


	while (Globalna::running->blockedThreads->prvi != 0 ) {
		PCB * tmp = Globalna::running->blockedThreads->take();
		tmp->state=threadReady;
		Scheduler::put(tmp);
	}

	Globalna::running->state=threadFinished;

	//if (Globalna::running->flagAmIidle == 1 ) assert (0);


	dispatch();



}
void PCB::run(){

}

