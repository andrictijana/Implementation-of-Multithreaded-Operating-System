/*
 * globalna.cpp
 *
 *  Created on: Aug 9, 2017
 *      Author: OS1
 */



#include "ivt.h"
#include"globalna.h"
#include "SCHEDULE.h"
#include"pcb.h"
#include <iostream.h>
#include <assert.h>
#include "Queue1.h"
#include <dos.h>
#include "kernsem.h"
#include "sortlist.h"
#include "idle.h"
#include "kernev.h"


Idle * Globalna::tidle;
pInterrupt Globalna::oldTimer;
int Globalna::dispatchFlag;
Thread * Globalna::firstThread;
PCB * Globalna::running;
Time Globalna::currentTime;

void Globalna::restore () {




#ifndef BCC_BLOCK_IGNORE

	setvect(0x08, oldTimer);
#endif
	delete tidle;

	delete KernelSem::sortList;
	delete KernelEv::kevents;
	delete IVTEntry::oldRoutines;
	//delete tidle;
	delete firstThread;





}


void Globalna::init() {

	KernelEv::kevents=new KernelEv * [256];

	for (int i=0 ; i< 256 ; i++ ) KernelEv::kevents[i]=0;
	tidle= new Idle();
	tidle->start();
	KernelSem::sortList=new SortList();

	firstThread=new Thread(nula, defaultTimeSlice);
	running=firstThread->myPCB;
	running->state=threadReady;
	dispatchFlag=0;

#ifndef BCC_BLOCK_IGNORE
	oldTimer=getvect(0x08);

	setvect(0x08, &timer);
	setvect(0x08, timer);

#endif

	currentTime=0;

	IVTEntry::oldRoutines= new pInterrupt [ 256];

	for (int ii=0; ii<256 ; ii++) IVTEntry::oldRoutines[ii]=0;



}
void tick();

void interrupt Globalna::timer(...) {

	if (dispatchFlag == 1) {
		currentTime=0;

		dispatchFlag=0;
		static unsigned tsp,tss,tbp;

#ifndef BCC_BLOCK_IGNORE
		asm {
			mov tsp, sp;
			mov tss, ss;
			mov tbp, bp;

		}
#endif
		running->sp=tsp;
		running->ss=tss;
		running->bp=tbp;

		if (running->state == threadReady)
			if (running->flagAmIidle == 0)
			Scheduler::put(running);

		running=Scheduler::get();

		if (running == 0) running=tidle->myPCB;

		//assert (running != 0);



		tsp=running->sp;
		tss=running->ss;
		tbp=running->bp;
#ifndef BCC_BLOCK_IGNORE
		asm {
			mov sp, tsp;
			mov ss, tss;
			mov bp, tbp;
		}
#endif




	}

	else {



	//	cout << "aaaaa" << endl;
		tick();

		/////////////////////////////////////////////////

	if (KernelSem::sortList->prvi != 0)  {
        while (KernelSem::sortList->prvi->time == 0 ) {

        	SortList::Elem * tmp = KernelSem::sortList->remove();
        	//cout<<"z t";
        	//assert(1);
        	tmp->blockedOn->value+=1;
        	PCB * pcb=tmp->blockedOn->blockedThreads->take(tmp->pcb);

        	tmp->pcb->flagWokeUp=0;

        	tmp->pcb->state=threadReady;
        	Scheduler::put(tmp->pcb);

        	delete tmp;

        	if (KernelSem::sortList->prvi == 0) break;


        }

        if (KernelSem::sortList->prvi != 0)
        KernelSem::sortList->prvi->time= KernelSem::sortList->prvi->time - 1;
		}
        //////////////////////////////

		if ( currentTime == running->timeSlice ) {

			dispatchFlag=1;
			timer();
		}

		currentTime+=1;

		(*oldTimer)();



	}


}
