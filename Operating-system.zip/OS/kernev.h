/*
 * kernev.h
 *
 *  Created on: Aug 12, 2017
 *      Author: OS1
 */

#ifndef KERNEV_H_
#define KERNEV_H_

typedef unsigned char IVTNo;
class PCB;
class KernelEv {

public:
	~KernelEv();
	void wait();
	void signal();
private:
	KernelEv(IVTNo, PCB *);
	friend class Event;

public:
	IVTNo ivtno;
	static KernelEv ** kevents;
	char flagBlocked;
	char flagSignaled;
	PCB * pcb;

};



#endif /* KERNEV_H_ */
