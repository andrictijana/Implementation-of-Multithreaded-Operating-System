/*
 * ivt.h
 *
 *  Created on: Aug 12, 2017
 *      Author: OS1
 */

#ifndef IVT_H_
#define IVT_H_

typedef unsigned char IVTNo;
typedef void interrupt (*pInterrupt) (...);
class IVTEntry {
public:
	~IVTEntry();
	IVTEntry(IVTNo, pInterrupt);
	void calloldSignal(int );

	static pInterrupt * oldRoutines;
	IVTNo ivtno;

};





#endif /* IVT_H_ */



#define PREPAREENTRY(ivtNo, flag)\
void interrupt routine##ivtNo(...);\
	IVTEntry ivtEntry##ivtNo(ivtNo,&routine##ivtNo);\
	void interrupt routine##ivtNo(...) {\
		if (flag) ivtEntry##ivtNo.calloldSignal(1);\
		ivtEntry##ivtNo.calloldSignal(2);\
		dispatch();\
	}
