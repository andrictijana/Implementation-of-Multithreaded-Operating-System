/*
 * queue.h
 *
 *  Created on: Aug 10, 2017
 *      Author: OS1
 */

#ifndef QUEUE_H_
#define QUEUE_H_

class PCB;

class Queue {
public:

	struct Elem {
		PCB * pcb;
		Elem * sled;
		Elem (PCB * tmp) {
			pcb=tmp; sled=0;
		}

	};

	Elem * prvi, * posl;
	Queue ();
	~Queue();
	void insert(PCB * pcb);
	PCB* take ();



};



#endif /* QUEUE_H_ */
