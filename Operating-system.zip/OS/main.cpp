/*
 * main.cpp
 *
 *  Created on: Aug 9, 2017
 *      Author: OS1
 */

#include"globalna.h"

 int userMain(int argc, char * argv []);

int main(int argc, char * argv[]) {

	Globalna::init();
	int ret=userMain(argc,argv);
	Globalna::restore();


}
