/*
 * globalna.h
 *
 *  Created on: Aug 9, 2017
 *      Author: OS1
 */

#ifndef GLOBALNA_H_
#define GLOBALNA_H_

#define lock asm { pushf; cli; }
#define unlock asm { popf; }
typedef void interrupt (*pInterrupt)(...);
class PCB;
class Thread;
class Idle;
typedef unsigned int Time;
class Globalna {

 public:
	static void init();
	 static void restore();

	 static PCB * running;
	 static pInterrupt oldTimer;
	 static void interrupt timer (...);

	 static int dispatchFlag;

	 static Thread * firstThread;

	 static Time currentTime;

	 static Idle * tidle;



 };



#endif /* GLOBALNA_H_ */
