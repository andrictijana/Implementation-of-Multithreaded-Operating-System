/*
 * semaphor.cpp
 *
 *  Created on: Aug 10, 2017
 *      Author: OS1
 */




#include "semaphor.h"
#include "kernsem.h"

#include "globalna.h"


void Semaphore::signal() {
#ifndef BCC_BLOCK_IGNORE
	lock
#endif

	myImpl->signal();

#ifndef BCC_BLOCK_IGNORE
	unlock
#endif



}


int Semaphore::wait(Time maxTime) {
#ifndef BCC_BLOCK_IGNORE
	lock
#endif

	int ret= myImpl->wait(maxTime);
#ifndef BCC_BLOCK_IGNORE
	unlock
#endif
	return ret;

}


Semaphore::Semaphore(int x) {
#ifndef BCC_BLOCK_IGNORE
	lock
#endif

	myImpl=new KernelSem(x);
#ifndef BCC_BLOCK_IGNORE
	unlock
#endif



}

Semaphore::~Semaphore() {
#ifndef BCC_BLOCK_IGNORE
	lock
#endif
	delete myImpl;

#ifndef BCC_BLOCK_IGNORE
	unlock
#endif


}


int Semaphore::val() const {
return myImpl->val();


}


