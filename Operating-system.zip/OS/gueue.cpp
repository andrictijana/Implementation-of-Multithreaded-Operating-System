/*
 * gueue.cpp
 *
 *  Created on: Aug 10, 2017
 *      Author: OS1
 */




#include "queue.h"
#include "pcb.h"


Queue::Queue() {
	prvi=posl=0;
}

Queue::~Queue() {

	Elem * stari;
	Elem * tmp;
	tmp=prvi;

	while (tmp != 0 ) {
		stari=tmp;
		tmp=tmp->sled;
		delete stari;
	}

	prvi=posl=0;
}


void Queue::insert(PCB * ni) {
	Elem * novi= new Elem (ni);
	if (posl == 0) {
		posl=prvi=novi;
	}
	else {
		posl->sled=novi;
	}

	posl=novi;
}


PCB * Queue::take() {

	if (prvi == 0 ) return 0;

	PCB * tmp = prvi->pcb;

	prvi=prvi->sled;
	if (prvi == 0 ) posl=0;

	return tmp;
}






















