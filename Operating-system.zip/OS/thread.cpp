/*
 * thread.cpp
 *
 *  Created on: Aug 9, 2017
 *      Author: OS1
 */




#include"pcb.h"
#include "globalna.h"

void Thread::start() {

#ifndef BCC_BLOCK_IGNORE
	lock
#endif

	myPCB->start();
#ifndef BCC_BLOCK_IGNORE
	unlock
#endif
}



void Thread::waitToComplete() {
#ifndef BCC_BLOCK_IGNORE
	lock
#endif

	myPCB->waitToComplete();
#ifndef BCC_BLOCK_IGNORE
	unlock
#endif
}

Thread::Thread(StackSize size, Time timeSlice) {
#ifndef BCC_BLOCK_IGNORE
	lock
#endif

	myPCB=new PCB (size, timeSlice, this);
#ifndef BCC_BLOCK_IGNORE
	unlock
#endif

}

Thread::~Thread() {
#ifndef BCC_BLOCK_IGNORE
	lock
#endif
	waitToComplete();
	delete myPCB;
#ifndef BCC_BLOCK_IGNORE
	unlock
#endif
}


void dispatch() {
#ifndef BCC_BLOCK_IGNORE
	lock
#endif
	 Globalna::dispatchFlag=1;
	 Globalna::timer();
#ifndef BCC_BLOCK_IGNORE
	unlock
#endif

}



