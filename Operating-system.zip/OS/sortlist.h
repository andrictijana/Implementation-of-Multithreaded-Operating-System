/*
 * sortlist.h
 *
 *  Created on: Aug 10, 2017
 *      Author: OS1
 */

#ifndef SORTLIST_H_
#define SORTLIST_H_
typedef unsigned int Time;
class KernelSem;
class PCB;
class SortList {
public:
	struct Elem {
		PCB * pcb;
		KernelSem * blockedOn;
		Time time;
		Elem * sled;

		Elem (PCB * tmp, KernelSem* tmp2, Time time) {
			pcb=tmp;
			blockedOn=tmp2;
			sled=0;
			this->time=time;
		}
	};




	void put(PCB * pcb, KernelSem * sem, Time time);
	Elem * get(PCB * pcb);
	Elem  * remove();

	SortList();
    ~SortList();

    Elem * prvi;

};



#endif /* SORTLIST_H_ */
