/*
 * kernev.cpp
 *
 *  Created on: Aug 12, 2017
 *      Author: OS1
 */

#include "kernev.h"
#include "globalna.h"
#include "pcb.h"
#include "schedule.h"

KernelEv ** KernelEv::kevents;

void KernelEv::signal(){

	if (flagBlocked == 0 ) {
		flagSignaled=1;
	}

	else {
		flagBlocked=0;

		pcb->state=threadReady;

		Scheduler::put(pcb);

	}



}

void KernelEv::wait() {

	if (flagSignaled == 0) {

	flagBlocked=1;

	Globalna::running->state=threadBlocked;

	dispatch();
	}
	else {
		flagSignaled=0;
	}

}

KernelEv::KernelEv(IVTNo ivtno, PCB * pcb) {

	kevents[ivtno]=this;

	this->ivtno=ivtno;

	flagBlocked=0;
	flagSignaled=0;

   this->pcb=pcb;


}


KernelEv::~KernelEv() {

	kevents[ivtno]=0;
	signal();


}
