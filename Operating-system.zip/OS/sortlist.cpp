/*
 * sortlist.cpp
 *
 *  Created on: Aug 10, 2017
 *      Author: OS1
 */




#include "sortlist.h"

#include "pcb.h"

#include "kernsem.h"


SortList::SortList() {
	prvi=0;
}

SortList::~SortList() {
	Elem * tmp= prvi;
	Elem * stari;
	while (tmp != 0 ) {
		stari=tmp;
		tmp=tmp->sled;
		delete stari;
	}
	prvi=0;
}


void SortList::put(PCB * pcb, KernelSem * sem, Time time) {
	Elem * novi = new Elem (pcb,sem, time);
	Elem * pret, * tek;
pret=0; tek=prvi;


	if (prvi == 0) {
		prvi=novi;
	}

	else {
		while (novi->time >= tek->time) {
				pret=tek;
				//tek=tek->sled;
				novi->time= novi->time - tek->time;
				tek=tek->sled;

			}
		if (pret == 0 ) {
			novi->sled=prvi;
			prvi->time= prvi->time - novi->time;
			prvi=novi;

		}
		else {
			pret->sled=novi;
			novi->sled=tek;
			tek->time=tek->time - novi->time;
		}
	}


}









SortList::Elem * SortList::get(PCB * pcb) {
	Elem * tek, * ret, *pret;
	tek=prvi; pret=0;
	if (prvi == 0) return 0;
	while (tek->pcb != pcb) {
		pret=tek;
		tek=tek->sled;

	}
	ret=tek;

	if (tek == prvi) {
		prvi->sled->time= prvi->sled->time + prvi->time;
		prvi=prvi->sled;
	}
	else {
		pret->sled=tek->sled;
		tek->sled->time=tek->sled->time + tek->time;

	}

	return ret;
}


SortList::Elem * SortList::remove() {

	if (prvi == 0 ) return 0;
	Elem * tek= prvi;
	prvi=prvi->sled;
	return tek;

}




