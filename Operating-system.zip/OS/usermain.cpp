/*
 * usermain.cpp
 *
 *  Created on: Aug 9, 2017
 *      Author: OS1
 */



#include "thread.h"
#include <iostream.h>
#include <stdlib.h>
#include "semaphor.h"

Semaphore sleep(0);
//Semaphore signl(0);
class Proba : public Thread {
public:
	Proba(char a) {
		this->a=a;
	}

	~Proba() {
		waitToComplete();
	}
	void run() {

		for ( int i=0; i< 100; i++)
                     	//for (int j=0; j<1000; j++)

		{
			//signl.signal();

			int xx= rand() % 4 + 1;
			sleep.wait(3);
				cout<<a;
				for ( int i=0; i< 1000; i++)
						for (int j=0; j<1000; j++);
				dispatch();
			}

		cout << endl << a << "finished" <<endl;
	}

	char a;
};

/*
class Signaler : public Thread {
public:
	Signaler(char a) {
		this->a=a;
	}

	~Signaler() {
		waitToComplete();
	}
	void run() {

		for ( int i=0; i< 400; i++)
                     	//for (int j=0; j<1000; j++)

		{

			signl.wait(0);
			sleep.signal();

			}

		cout << endl << a << "finished" <<endl;
	}

	char a;
};
*/
void tick() {

}


int userMain(int argc, char * argv [] ) {

	Proba * p1 = new Proba ('a');
	Proba * p2 = new Proba ('b');
	Proba * p3 = new Proba ('c');
	Proba * p4 = new Proba ('d');

	//Signaler * s1= new Signaler('x');

	p1->start();
	p2->start();
	p3->start();
	p4->start();

//	s1->start();

	//while(1);

	delete p1;
	delete p2;
	delete p3;
	delete p4;
	//delete s1;

	cout << "usermain finished";



	return 0;
}
