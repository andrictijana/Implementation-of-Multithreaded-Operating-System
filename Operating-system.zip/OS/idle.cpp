/*
 * idle.cpp
 *
 *  Created on: Aug 11, 2017
 *      Author: OS1
 */




#include "idle.h"
#include "pcb.h"

#include <assert.h>
#include "globalna.h"

void Idle::run() {


	 for (; radi == 1 ; ) {
		 dispatch();
	 }

	// assert(0);




}


Idle::~Idle() {

	radi=0;
// assert (0);

	waitToComplete();
	//assert(0);

}


Idle::Idle() {

	radi=1;

	myPCB->flagAmIidle=1;


}
