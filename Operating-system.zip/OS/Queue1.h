/*
 * Queue1.h
 *
 *  Created on: Aug 10, 2017
 *      Author: OS1
 */

#ifndef QUEUE1_H_
#define QUEUE1_H_

class PCB;

class Queue1 {
public:

	struct Elem {
		int flagInfiniteWait;
		PCB * pcb;
		Elem * sled;
		Elem (PCB * tmp, int x) {
			pcb=tmp; sled=0;
			this->flagInfiniteWait=x;
		}

	};

	Elem * prvi, * posl;
	Queue1 ();
	~Queue1();
	void insert(PCB * pcb, int x);
	Elem* take ();
	PCB * take (PCB * pcb);



};



#endif /* QUEUE1_H_ */
