/*
 * pcb.h
 *
 *  Created on: Aug 9, 2017
 *      Author: OS1
 */

#ifndef PCB_H_
#define PCB_H_

#include"thread.h"

typedef int threadState;

const threadState threadNew = 100;
const threadState threadBlocked = 101;
const threadState threadFinished = 102;
//const threadState threadStarted = 103;
const threadState threadReady = 104;
class Queue;
class PCB {
public:


	PCB(StackSize size, Time timeslice, Thread * nit);
	~PCB();
	void waitToComplete();

	void start();
	void run();

	StackSize size;
	Time timeSlice;
	Thread * nit;

	unsigned sp, ss, bp;
	unsigned * stack;

	static unsigned maxStackSize;

	static void wrapper();

	threadState state;

	int flagAmIidle;

    int flagStarted;

	Queue * blockedThreads;

	int flagWokeUp;



};



#endif /* PCB_H_ */
