/*
 * kernsem.h
 *
 *  Created on: Aug 10, 2017
 *      Author: OS1
 */

#ifndef KERNSEM_H_
#define KERNSEM_H_

typedef unsigned int Time;
class SortList;
class Queue1;
class KernelSem {
public:

	KernelSem(int val);
	~KernelSem();
	int wait(Time maxTimeToWait );
	void signal();
	int val();


	Queue1 * blockedThreads;
	int value;


	static SortList * sortList;



};




#endif /* KERNSEM_H_ */
