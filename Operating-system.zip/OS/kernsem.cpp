/*
 * kernsem.cpp
 *
 *  Created on: Aug 10, 2017
 *      Author: OS1
 */

#include "kernsem.h"
#include "queue.h"
#include "pcb.h"
#include "sortlist.h"
#include "Queue1.h"
#include "schedule.h"
#include "globalna.h"
SortList * KernelSem::sortList;


void KernelSem::signal() {

	value= value + 1;
	if (value <= 0) {

		Queue1::Elem * tmp=blockedThreads->take();

		tmp->pcb->state=threadReady;
		Scheduler::put(tmp->pcb);

		if (tmp->flagInfiniteWait == 0 ) {

			sortList->get(tmp->pcb);
		}

		tmp->pcb->flagWokeUp=1;

		delete tmp;


	}

}


int KernelSem::wait(Time maxTime) {

	value= value - 1;

	if (value >= 0) return 1;

	if (value < 0 ) {

		Globalna::running->state=threadBlocked;

		int x; if (maxTime == 0) x=1; else x=0;

		blockedThreads->insert(Globalna::running, x);

		if (x == 0) {
			sortList->put(Globalna::running, this, maxTime);
		}
		dispatch();

		return Globalna::running->flagWokeUp;



	}



}


KernelSem::KernelSem(int val) {


	this->value=val;
	blockedThreads=new Queue1();

}


KernelSem::~KernelSem() {



	while (value > 0) signal();

	delete blockedThreads;


}


int KernelSem::val() {
	return value;
}
