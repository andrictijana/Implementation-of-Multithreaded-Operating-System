/*
 * event.h
 *
 *  Created on: Aug 12, 2017
 *      Author: OS1
 */

#ifndef EVENT_H_
#define EVENT_H_



#include "ivt.h"


typedef unsigned char IVTNo;
class KernelEv;
class PCB;

class Event {

public:

   Event (IVTNo ivtNo);
   ~Event ();
   void wait();

protected:

   void signal(); // can call KernelEv

private:

   KernelEv* myImpl;

   PCB* pcb;

   friend class KernelEv;

};

#endif /* EVENT_H_ */
