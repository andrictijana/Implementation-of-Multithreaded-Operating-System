/*
 * ivt.cpp
 *
 *  Created on: Aug 12, 2017
 *      Author: OS1
 */



#include <dos.h>
#include "ivt.h"
#include "globalna.h"
#include "kernev.h"



pInterrupt * IVTEntry::oldRoutines;



IVTEntry::IVTEntry(IVTNo ivtno, pInterrupt newRoutine){
#ifndef BCC_BLOCK_IGNORE
	lock
	oldRoutines[ivtno]=getvect(ivtno);
	setvect(ivtno,newRoutine);
#endif

	this->ivtno=ivtno;

#ifndef BCC_BLOCK_IGNORE
	unlock
#endif

}


IVTEntry::~IVTEntry(){

#ifndef BCC_BLOCK_IGNORE
	lock
	setvect(ivtno,oldRoutines[ivtno]);
#endif

   if ( oldRoutines[ivtno])
	  ( *oldRoutines[ivtno] )();

#ifndef BCC_BLOCK_IGNORE

	unlock
#endif
}


void IVTEntry::calloldSignal(int x){
#ifndef BCC_BLOCK_IGNORE
	lock
#endif

	if (x == 1) {
		if (oldRoutines[ivtno] != 0)
			(*oldRoutines[ivtno])();
	}
	if (x == 2) {
		if (KernelEv::kevents[ivtno] != 0 )
			KernelEv::kevents[ivtno]->signal();
	}
#ifndef BCC_BLOCK_IGNORE
	unlock
#endif
}


