/*
 * event.cpp
 *
 *  Created on: Aug 12, 2017
 *      Author: OS1
 */




#include "event.h"
#include "globalna.h"
#include "kernev.h"

Event::~Event() {
#ifndef BCC_BLOCK_IGNORE
	lock
#endif
	pcb=0;
	delete myImpl;

#ifndef BCC_BLOCK_IGNORE
	unlock
#endif


}


void Event::signal() {
	#ifndef BCC_BLOCK_IGNORE
	lock
#endif
myImpl->signal();

#ifndef BCC_BLOCK_IGNORE
	unlock
#endif

}

void Event::wait() {
#ifndef BCC_BLOCK_IGNORE
	lock
#endif
	if (Globalna::running==pcb)
myImpl->wait();

#ifndef BCC_BLOCK_IGNORE
	unlock
#endif
}

Event::Event(IVTNo ivtno) {
#ifndef BCC_BLOCK_IGNORE
	lock
#endif
 pcb=Globalna::running;
	myImpl=new KernelEv(ivtno, pcb);
#ifndef BCC_BLOCK_IGNORE
	unlock
#endif

}
